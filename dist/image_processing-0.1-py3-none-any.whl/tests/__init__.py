# tests/__init__.py

# Este arquivo indica que a pasta "tests" é um pacote Python.
# Pode ser deixado vazio ou incluir configurações específicas para os testes.